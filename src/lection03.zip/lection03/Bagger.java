package lection03;

public interface Bagger extends Baumaschine{
    static final double MAX_GRABTIEFE = 15d;
    static final double MAX_REICHWEITE = 18d;

    public double getGrabtiefe();
    public void setGrabtiefe(double grabtiefe);
    public double getReichweite();
    public void setReichweite(double reichweite);
    public void druckeBeschreibung();
}
