package lection03;

public interface Lader extends Baumaschine {
    static final double MAX_SCHAUFELVOLUMEN = 10;
    static final double MAX_KIPPHOEHE = 5;

    public double getSchaufelvolumen();
    public void setSchaufelvolumen(double schaufelvolumen);
    public double getKipphoehe();
    public void setKipphoehe(double kipphoehe);
    public void druckeBeschreibung();
}
