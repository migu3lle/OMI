package lection03;

public interface Baggerlader extends Bagger, Lader {
    public void druckeBeschreibung();
}
